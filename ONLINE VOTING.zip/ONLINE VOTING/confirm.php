<?php
session_start();
?>
<?php
	include 'connection.php';
	$id=$_SESSION['ids'];
	$candid=$_SESSION['candid'];
$update1=mysqli_query($con,"update trainees set Status=Status+1 where Sid='$id'");
$update2=mysqli_query($con,"update candidates set Marks=Marks+1 where Cand_id='$candid'");
if($update1 && $update2){
	header('location:login.php');
}
else{
	echo "Failed to vote";
}
?>