<?php
session_start();
?>
<html>
<body>
	<form method="POST">
		USER ID: <input type="number" name="id"><br><br>
		<input type="submit" name="sub" value="LOGIN">
	</form>
	<?php
	if (isset($_POST['sub'])) {
include 'connection.php';
$id=$_POST['id'];
$checking=mysqli_query($con,"select * from trainees where Sid='$id'");
$fech=mysqli_fetch_array($checking);
//checking whether the user is exist
if (is_array($fech)) {
//checking Status
	if($fech['Status']<2){
		$_SESSION['ids']=$fech['Sid'];
		$_SESSION['fullname']=$fech['Fullname'];
header('location:Votingpage.php');
	}
	else{
		echo "You have finished to Vote";
	}
}
else{
	echo "Your id is not matching!!";
}
}
	?>
</body>
	</html>