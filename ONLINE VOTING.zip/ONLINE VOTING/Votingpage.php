<?php
session_start();
?>
<head>
	<title>VOTING PAGE</title>
</head>
<p>Welcome,<b><?php echo $_SESSION['fullname'];?></b></p>
<?php
$id=$_SESSION['ids'];
include 'connection.php';
$sel=mysqli_query($con,"select * from trainees where Sid='$id'");
$feci=mysqli_fetch_array($sel);
echo "<img src=".$feci['Profile']." width=200px height=255px>";
?><br><br>
<a href="Realvote.php" style="color: darkblue; text-decoration: none;font-weight: bold;">Yes Is me</a>
<a href="login.php" style="color: red; text-decoration: none;font-weight: bold;">Not me</a>
