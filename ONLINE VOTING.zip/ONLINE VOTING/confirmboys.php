<?php
session_start();
?>
<?php
	include 'connection.php';
	$id=$_SESSION['ids'];
	$candid=$_GET['boys'];
$update1=mysqli_query($con,"update trainees set Status=Status+1 where Sid='$id'");
$update2=mysqli_query($con,"update candidates set Marks=Marks+1 where Cand_id='$candid'");
$update3=mysqli_query($con,"update trainees set Boys=Boys+1 where Sid='$id'");
if($update1 && $update2 && $update3){
	header('location:login.php');
}
else{
	echo "Failed to vote";
}
?>