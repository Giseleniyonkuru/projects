<?php
session_start();
?>
<head>
	<title>REAL VOTING PAGE</title>
</head>
<body>
	<form method="POST">
	<b>Select Your Choise</b>
	<?php
include 'connection.php';
$selss=mysqli_query($con,"select * from post");
while ($fet=mysqli_fetch_array($selss)) {
?>
<input type="radio" name="post" value="<?php echo $fet['Post_id'];?>"><?php echo $fet['Post_Name'];?>

<?php
}
?>
<br><br>
<input type="submit" name="sub" value="CHECKING AVAILABLE CANDIDATE">
</form>
<?php
if(isset($_POST['sub'])){
include 'connection.php';
$POST=$_POST['post'];
$SID=$_SESSION['ids'];
if($POST==1){
$selee=mysqli_query($con,"select * from trainees where Sid='$SID'");
$fk=mysqli_fetch_array($selee);
if($fk['Boys']<1){
	$qry=mysqli_query($con,"select trainees.*,candidates.*,post.* from trainees,candidates,post where trainees.Sid=candidates.sid and post.Post_id=candidates.Post_id and post.Post_id='$POST'");
	while($feth1=mysqli_fetch_array($qry)){
?>
<table border="2">
	<tr>
		<td><?php echo $feth1['Fullname'];?></td>
		<td><a href="confirmboys.php?boys=<?php echo $feth1['Cand_id'];?>">Vote now</a></td>
	</tr>
</table>
<?php
	}
}
	else{
		echo "You are not allowed to vote Boys Twice";
	}
}
else{
	$sel2=mysqli_query($con,"select * from trainees where Sid='$SID'");
$fk=mysqli_fetch_array($sel2);
if($fk['Girls']<1){
$qryy=mysqli_query($con,"select trainees.*,candidates.*,post.* from trainees,candidates,post where trainees.Sid=candidates.sid and post.Post_id=candidates.Post_id and post.Post_id='$POST'");
	while($feth2=mysqli_fetch_array($qryy)){
?>
<table border="2">
	<tr>
		<td><?php echo $feth2['Fullname'];?></td>
		<td><a href="confirmgirls.php?girls=<?php echo $feth2['Cand_id'];?>">Vote now</a></td>
	</tr>
</table>
<?php
}
}
else{
	echo "You are not allowed to vote Girls Twice";
}
}
}
?>
</body>
(select * from candidates where Post_id=1 order by Marks desc limit 1) UNION (select * from candidates where Post_id=2 order by Marks desc limit 1);
