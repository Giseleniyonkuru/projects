<html>
<head>
	
</head>
<body>
	<form method="POST" enctype="multipart/form-data">
STUDENT ID: <input type="number" name="id" required><br><br>
FULL NAMES: <input type="text" name="fname"><br><br>
SEX: <select name="sex">
	<option value="Male">MALE</option>
	<option value="Female">FEMALE</option>
</select><br><br>
Choose Your Profile: <input type="file" name="files" accept=".jpg,.png"><br><br>
<input type="submit" name="sub" value="CREATE ACCOUNT">
	</form>
	<?php
if(isset($_POST['sub'])){
include 'connection.php';
$ID=$_POST['id'];
$FNAME=$_POST['fname'];
$SEX=$_POST['sex'];
$PROFILE=$_FILES['files']['tmp_name'];
$PATH='Uploads/'.$_FILES['files']['name'];
move_uploaded_file($PROFILE,$PATH);
$chk=mysqli_query($con,"select * from trainees where Sid='$ID'");
$fet=mysqli_fetch_array($chk);
if(is_array($fet)){
	echo "You are using existing Id";
}
else{
$creat=mysqli_query($con,"insert into trainees values('$ID','$FNAME','$SEX','','$PATH')");
if ($creat) {
echo "Acount is created";
}
else{
	echo "Fails to create Account";
}
}
}
	?>
</body>
</html>